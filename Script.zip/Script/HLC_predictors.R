# Libraries ####
library(sp) #spatial points
library(raster) # to read raster data
library(sf) # spatial analysis
library(dplyr) # for data manipulation (dplyr) 
library(dismo)
library(caTools)
library(caret)
library(car)
library(performance) # to check model performance
library(readxl)#read excel files
library(Metrics) #
library(e1071) # 
library(ExtractTrainData)  # to extract datapoints
library(yardstick)   # to estimate the accuracy of model
library(pROC)
library(ROCR)        # to compute and plot Reciever Opering Curve
library(GGally) # to check corelation
library(tidyverse)
library(ellipse)
library(rJava)
library(XML)
library(RColorBrewer) #palfunc color ramp in map

setwd("C:/Users/SNNP")

# Projections ####
wgs1984.proj <- st_crs("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
UTMZ45 <- st_crs("+proj=utm +zone=45 +datum=WGS84 +units=m +no_defs")
wgs1984_crs <- CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
utm45n <- CRS("+proj=utm +zone=45 +datum=WGS84 +units=m +no_defs")

#load shape file####
ktm<-st_read("Data/shape_file/ktm_buffer.shp")
ktm_crs <-  ktm
ktm_buffer <- st_buffer(ktm_crs, dist=2)

## load DEM file####
dem<-raster("Predictors/srtm_ktm/srtm_54_07.tif")

## elevation ####
dem_ktm <- crop(dem, ktm_crs)
plot(dem_ktm)
writeRaster(dem_ktm, filename = "Predictors/dem_ktm.tif", overwrite=TRUE)

## slope ####
slope_ktm<-terrain(dem_ktm, opt= "slope", unit= "degrees", neighbors=8)
writeRaster(slope_ktm, filename = "Predictors/slope_ktm.tif", overwrite=TRUE)

## aspect ####
aspect_ktm <-terrain(dem_ktm, opt= "aspect",unit= "degrees", neighbors=8)
writeRaster(aspect_ktm, filename = "Predictors/aspect_ktm.tif", overwrite=TRUE)

## worldclim data####
worldclim<-stack("Predictors/shape_file/World_clim_nepal.tif")
#projection(worldclim)
worldclim_crop<-crop(worldclim,ktm_crs)
worldclim_re<-resample(worldclim_crop,dem_ktm,method ="bilinear")
#save(worldclim_re, file="Data/worldclim_recampled.RData")
load("Data/worldclim_recampled.RData")
writeRaster(worldclim_re, filename = "Predictors/worldclim_re.tif", overwrite=TRUE)

##human footprint####
hfp <- raster('Predictors/wildareas-v3-2009-human-footprint-geotiff/wildareas-v3-2009-human-footprint_pr.tif')
hfp_crop<-crop(hfp,ktm_crs)
hfp_re <- resample(hfp_crop, dem_ktm, method = "bilinear")
#save(hfp_re, file= "Data/hfp_resampled.RData")
load("Data/hfp_resampled.RData")
hfp_re
writeRaster(hfp_re, filename = "Predictors/hfp_re.tif", overwrite=TRUE)

##human influence index####
hii <- raster('Predictors/hii-asia-geo-grid/hii_asia/w001001.adf')
crs(hii)<-wgs1984.proj
hii_crop<-crop(hii,ktm_crs)
hii_re <- resample(hii_crop, dem_ktm, method = "bilinear")
plot(hii_re)
hii_re
#save(hii_re, file= "Data/hii_resampled.RData")
load("Data/hii_resampled.RData")
writeRaster(hii_re, filename = "Predictors/hii_re.tif", overwrite=TRUE)

##NDVI####
ndvi <- raster('Predictors/shape_file/ndvi_ktm_2024.tif')
crs(ndvi)<-wgs1984.proj
ndvi_crop<-crop(ndvi,ktm_crs)
ndvi_re <- resample(ndvi_crop, dem_ktm, method = "bilinear")
#save(ndvi_re, file= "Data/ndvi_resampled.RData")
load("Data/ndvi_resampled.RData")
writeRaster(ndvi_re, filename = "Predictors/ndvi_re.tif", overwrite=TRUE)

##human population density####
hpd<- raster('Predictors/gpw-v4-population-count-rev11_2015_30_sec_tif/gpw_v4_population_count_rev11_2015_30_sec.tif')
crs(hpd)<-wgs1984.proj
hpd_crop<-crop(hpd,ktm_crs)
hpd_re <- resample(hpd_crop, dem_ktm, method = "bilinear")
#save(hpd_re, file= "Data/hpd_resampled.RData")
writeRaster(hpd_re, filename = "Predictors/hpd_re.tif", overwrite=TRUE)
load("Data/hpd_resampled.RData")

##canopy cover####
ccov<-raster("Predictors/GFCC30TC_p141r041_TC_2015/p141r041_TC_2015_pr.tif")
ccov_crop<-crop(ccov,ktm_crs)
ccov_re <- resample(ccov_crop, dem_ktm, method = "bilinear")
#save(ccov_re, file= "Data/ccov_resampled.RData")
load("Data/ccov_resampled.RData")
writeRaster(ccov_re, filename = "Predictors/ccov_re.tif", overwrite=TRUE)

#predictor tiff####

#nearest distance to waterbody####
water <- raster("Predictors/snnp_raster/near_water.tif")
crs(water)<- utm45n
water1 <- projectRaster(water, crs=wgs1984_crs)
water_crop <- crop(water1, ktm_crs)
water_re <- resample(water_crop, dem_ktm, method= "bilinear")
#water_re_m <- water_re*1000
writeRaster(water_re, filename = "Predictors/water_re_m.tif", overwrite=TRUE)

#nearest distance to OWL####
owl<- raster("Predictors/snnp_raster/near_owl.tif")
crs(owl)<- utm45n
owl1 <- projectRaster(owl, crs=wgs1984_crs)
owl_crop <- crop(owl1, ktm_crs)
owl_re <- resample(owl_crop, dem_ktm, method= "bilinear")
#owl_re_m <- owl_re*1000
writeRaster(owl_re, filename = "Predictors/owl_re_m.tif", overwrite=TRUE)

#nearest distance to grassland####
grassland <- raster("Predictors/snnp_raster/near_grassland.tif")
crs(grassland)<- utm45n
grassland1 <- projectRaster(grassland, crs=wgs1984_crs)
grassland_crop <- crop(grassland1, ktm_crs)
grassland_re <- resample(grassland_crop, dem_ktm, method= "bilinear")
#grassland_re_m <- grassland_re*1000
writeRaster(grassland_re, filename = "Predictors/grassland_re_m.tif", overwrite=TRUE)

#nearest distance to cropland####
cropland <- raster("Predictors/snnp_raster/near_cropland.tif")
crs(cropland)<- utm45n
cropland1 <- projectRaster(cropland, crs=wgs1984_crs)
cropland_crop <- crop(cropland1, ktm_crs)
cropland_re <- resample(cropland_crop, dem_ktm, method= "bilinear")
#cropland_re_m <- cropland_re*1000
writeRaster(cropland_re, filename = "Predictors/cropland_re_m.tif", overwrite=TRUE)

#end####


