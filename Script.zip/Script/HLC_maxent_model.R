# Libraries ####
library(sp) #spatial points
library(raster) # to read raster data
library(sf) # spatial analysis
library(dplyr) # for data manipulation (dplyr) 
library(dismo)
library(caTools)
library(caret)
library(car)
library(performance) # to check model performance
library(readxl)#read excel files
library(Metrics) #
library(e1071) # 
library(ExtractTrainData)  # to extract datapoints
library(yardstick)   # to estimate the accuracy of model
library(pROC)
library(ROCR)        # to compute and plot Reciever Opering Curve
library(GGally) # to check corelation
library(tidyverse)
library(ellipse)
library(rJava)
library(XML)
library(RColorBrewer) #palfunc color ramp in map

setwd("C:/Users/SNNP")

# Projections ####
wgs1984.proj <- st_crs("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
UTMZ45 <- st_crs("+proj=utm +zone=45 +datum=WGS84 +units=m +no_defs")
wgs1984_crs <- CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
utm45n <- CRS("+proj=utm +zone=45 +datum=WGS84 +units=m +no_defs")



#multicolinearity test ####

# Read the data
all_2 <- read.csv("Data/all_variables_snnp.csv") 

# Inspect column names
names(all_2)

# Remove specific columns (adjust indexing as needed for your dataset)
all_f <- all_2[, -c(1:2, 4:5, 11, 13,33:35)]

# Calculate the correlation matrix
cor_matrix <- cor(all_f, use = "pairwise.complete.obs") # Ensures no missing data issues
print(cor_matrix)

# Identify highly correlated features
high_f <- findCorrelation(cor_matrix, cutoff = 0.9, names = FALSE) # Ensure index output
print(high_f)

# Remove highly correlated features
reduced_all_f <- all_f[, -high_f]
print(reduced_all_f)

# Inspect column names of the reduced dataset
names(reduced_all_f)

# Fit a linear model with the dummy dependent variable
model <- lm(PA ~ ., data = reduced_all_f)

# Calculate VIF for the independent variables
vif_f <- vif(model)
print(vif_f)

# Print the number of independent variables
length(vif_f)

# Print the names of independent variables with their VIF values
names(vif_f) <- colnames(reduced_all_f[, -1]) # Assuming 'PA' is the dependent variable
print(names(vif_f))

#maxent modeling####

##final predictors ####
pred <- list.files("Predictors/Final_predictors", pattern=".tif", full.names = TRUE)

pred_final <- stack(pred) 
names(pred_final)
names(pred_final) <- c("Aspect", "Canopy.Cover", 
                       "Nearest.Distance.to.Cropland","Elevation",
                       "Nearest.Distance.to.Grassland",  
                       "Human.Influence.Index", "NDVI",
                       "Nearest.Distance.to.OWL","Slope",
                       "Nearest.Distance.to.Waterbody","BIO1","BIO2","BIO3", "Temperature.Seasonality", 
                       "BIO5","Min Temperature of Coldest Month", "BIO7","BIO8","Mean Temperature of Driest Quarter","BIO10","BIO11","BIO12",
                       "Precipitation of Wettest Month", "Precipitation of Driest Month", "BIO15","Precipitation of Wettest Quarter","BIO17","BIO18","BIO19")

##Selected predictors####
# [1] "Slope"          "Aspect"         "HII"            "NDVI"          
# [5] "Tree_cover"     "BIO4"           "BIO6"           "BIO9"          
# [9] "BIO13"          "BIO14"          "BIO16"          "Dist_cropland" 
# [13] "Dist_water"     "Dist_OWL"       "Dist_grassland" 
pred_vif <- pred_final[[c(1:3,5:10,14,16,19,23,24,26)]]
names(pred_vif)

##occurence data####
hlc <- read_excel(file.choose(),2) #Load Shrestha_HLC_data.xlxs

## Set coordinates and CRS for 'hlc'
coordinates(hlc) <- ~Long + Lat 
proj4string(hlc) <- utm45n  
hlc_wgs <- spTransform(hlc, wgs1984_crs)  # Transform to WGS84

##spatial autocorrealtion####
# Function to remove closely spaced points
thin_points <- function(points, distance) {
  # Calculate the distance matrix (in kilometers since longlat = TRUE)
  dist_matrix <- spDists(points, longlat = TRUE)
  
  # Initialize a logical vector to keep points
  keep <- rep(TRUE, nrow(points))
  
  # Loop through points and remove those within the specified distance
  for (i in 1:nrow(points)) {
    if (keep[i]) {
      close_points <- which(dist_matrix[i, ] < distance & dist_matrix[i, ] > 0)
      keep[close_points] <- FALSE
    }
  }
  
  # Return the thinned points
  return(points[keep, ])
}

# Define the distance threshold (e.g., 1 km)
distance_threshold <- 1  # in kilometers

# Apply the function to thin the points
thinned_points <- thin_points(hlc_wgs, distance_threshold)

# Convert the thinned points to a SpatialPointsDataFrame
thinned_sp <- SpatialPointsDataFrame(
  coords = coordinates(thinned_points),
  data = as.data.frame(hlc_wgs)[row.names(thinned_points), ],
  proj4string = CRS(proj4string(hlc_wgs))
)

# Convert to a data frame for MaxEnt
thinned_df <- as.data.frame(thinned_sp)
hlc_thin <- thinned_df[, c(2:3)]  # Adjust column names as per your dataset

# Count the number of points
n_points <- nrow(hlc_thin)
print(n_points)



# 10 fold cross validation
fold <- kfold(hlc_thin , k=10) 
hlc_test <- hlc_thin [fold == 1, ]
hlc_train <- hlc_thin [fold != 1, ]

# test if you can use maxent 
maxent()

## fit model####
hlc_model <- maxent(x= pred_vif, p= hlc_train, args= c("-J",                        # Jackknife to measure variable importance
                                                       "replicates=25",             # Number of replications
                                                       "replicatetype=Bootstrap",
                                                       "randomseed",                # Replication type (can be changed)
                                                       "outputformat=raw", 
                                                       "responsecurves=true")) # Save response curves    
hlc_model 
#save(hlc_model, file= "Data/maxent12_24.RData")

#load("Data/maxent12_24.RData")

# plot showing importance of each variable
plot(hlc_model)


# Get the response curve
dismo::response(hlc_model, var = 10, ylim = c(0, 0.6))

dismo::response(hlc_model,2)
dismo::response(hlc_model,4)
dismo::response(hlc_model,6)


## predict to entire dataset ####
hlc_pred <- predict(hlc_model, pred_vif) 

plot(hlc_pred)
mean_pred <- mean(hlc_pred)
plot(mean_pred, main = "Mean Predicted Conflict Hotspot")
sd_pred <- calc(hlc_pred, sd)
plot(sd_pred, main = "Standard Deviation of Predictions")
writeRaster(mean_pred, "mean_prediction1.tif", format = "GTiff", overwrite = TRUE)
writeRaster(hlc_pred, "replicate_predictions1.tif", format = "GTiff", overwrite = TRUE)

writeRaster(hlc_pred, filename = "Output/snnp_55_map1.tif")

dev.off()

plot(hlc_pred)
points(hlc_thin)

writeRaster(hlc_pred, file= "maxent_snnp_55.tif", overwrite=TRUE)

##validation on test dataset ####
# background data
bg <- randomPoints(pred_vif, 10000)

##for all replicates
replicate_results <- lapply(hlc_model@models, function(model) {
  dismo::evaluate(model, p = hlc_test, a = bg, x = pred_vif)
})

# Combine evaluation results (e.g., mean AUC)
mean_auc <- mean(sapply(replicate_results, function(e) e@auc))
print(mean_auc)
threshold(mean_auc)
plot(mean_auc)


#end####