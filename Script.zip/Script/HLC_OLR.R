# Library####
library(MASS)
library(ggplot2)
library(dplyr)
library(tidyr)
library(lmtest)


#Ordinal Logistic Regression####


#Gender####
# Create the data frame for Gender
gender_data <- data.frame(
  Gender = factor(rep(c("Male", "Female"), each = 3)),
  Response = factor(rep(c("Positive", "Neutral", "Negative"), 2), ordered = TRUE, levels = c("Negative", "Neutral", "Positive")),
  Count = c(489, 67, 76, 320, 53, 59)
)

# Fit the ordinal regression model
gender_model <- polr(Response ~ Gender, data = gender_data, weights = Count)

# Display the summary of the model
summary(gender_model)

lrtest(gender_model)

# Create a new data frame for predictions
predict_data <- data.frame(
  Gender = factor(c("Male", "Female"), levels = c("Male", "Female"))
)

# Predict probabilities for each gender
predicted_probs <- as.data.frame(predict(gender_model, newdata = predict_data, type = "probs"))
predicted_probs$Gender <- predict_data$Gender

# Reshape the data for plotting
plot_data <- predicted_probs %>%
  pivot_longer(cols = c("Negative", "Neutral", "Positive"), names_to = "Response", values_to = "Probability")

# Create the barplot
gen_plot <- ggplot(plot_data, aes(x = Gender, y = Probability, fill = Response)) +
  geom_bar(stat = "identity", position = "dodge") +
  scale_fill_manual(values = c("Negative" = "darkred", "Neutral" = "blue", "Positive" = "forestgreen")) + 
  labs(x = "Gender",
       y = "Probability") +
  theme_classic()+
theme(
  axis.title = element_text(size = 16),  # Increase axis labels font size
  axis.text = element_text(size = 14)    # Increase tick labels font size
)

#Education####
# Create the data frame for education
edu_data <- data.frame(
  edu = factor(rep(c("Higher","Intermediate", "Lower"), each = 3)),
  Response = factor(rep(c("Positive", "Neutral", "Negative"), 3), ordered = TRUE, levels = c("Negative", "Neutral", "Positive")),
  Count = c(231, 18, 25,289, 40,44, 242, 52, 47)
)

# Fit the ordinal regression model
edu_model <- polr(Response ~ edu, data = edu_data, weights = Count)

# Display the summary of the model
summary(edu_model)
lrtest(edu_model)
# Create a new data frame for predictions
predict_data_edu <- data.frame(
  edu = factor(c("Higher","Intermediate", "Lower"), levels = c("Higher","Intermediate", "Lower"))
)

# Predict probabilities for each socioeconomic status
predicted_probs_edu <- as.data.frame(predict(edu_model, newdata = predict_data_edu, type = "probs"))
predicted_probs_edu$edu <- predict_data_edu$edu

# Reshape the data for plotting
plot_data_edu <- predicted_probs_edu %>%
  pivot_longer(cols = c("Negative", "Neutral", "Positive"), names_to = "Response", values_to = "Probability")

# Create the barplot
edu_plot <- ggplot(plot_data_edu, aes(x = edu, y = Probability, fill = Response)) +
  geom_bar(stat = "identity", position = "dodge") +
  scale_fill_manual(values = c("Negative" = "darkred", "Neutral" = "blue", "Positive" = "forestgreen")) + 
  labs(x = "Education level",
       y = "Probability") +
  theme_classic()+
  theme(
    axis.title = element_text(size = 16),  # Increase axis labels font size
    axis.text = element_text(size = 14)    # Increase tick labels font size
  ) 
 
#Location####
# Create the data frame for Location
location_data <- data.frame(
  Location = factor(rep(c("Inside_Buffer", "Outside_Buffer"), each = 3)),
  Response = factor(rep(c("Positive", "Neutral", "Negative"), 2), ordered = TRUE, levels = c("Negative", "Neutral", "Positive")),
  Count = c(443, 41, 116, 376, 79, 19)
)

# Fit the ordinal regression model
location_model <- polr(Response ~ Location, data = location_data, weights = Count)

# Display the summary of the model
summary(location_model)
lrtest(location_model)
# Create a new data frame for predictions
predict_data_location <- data.frame(
  Location = factor(c("Inside_Buffer", "Outside_Buffer"), levels = c("Inside_Buffer", "Outside_Buffer"))
)

# Predict probabilities for each location
predicted_probs_location <- as.data.frame(predict(location_model, newdata = predict_data_location, type = "probs"))
predicted_probs_location$Location <- predict_data_location$Location

# Reshape the data for plotting
plot_data_location <- predicted_probs_location %>%
  pivot_longer(cols = c("Negative", "Neutral", "Positive"), names_to = "Response", values_to = "Probability")

# Create the barplot
loc_plot <- ggplot(plot_data_location, aes(x = Location, y = Probability, fill = Response)) +
  geom_bar(stat = "identity", position = "dodge") +
  scale_fill_manual(values = c("Negative" = "darkred", "Neutral" = "blue", "Positive" = "forestgreen")) + 
  labs(x = "Location",
       y = "Probability") +
  theme_classic()+
  theme(
    axis.title = element_text(size = 16),  # Increase axis labels font size
    axis.text = element_text(size = 14)    # Increase tick labels font size
  )

#Age####
# Create the data frame for age
age_data <- data.frame(
  age = factor(rep(c("18-35","35-55", "55-70", "70 and above"), each = 3)),
  Response = factor(rep(c("Positive", "Neutral", "Negative"), 4), ordered = TRUE, levels = c("Negative", "Neutral", "Positive")),
  Count = c(388,46,60,310,51,55,97,20,14,14,3,6)
)

# Fit the ordinal regression model
age_model <- polr(Response ~ age, data = age_data, weights = Count)

# Display the summary of the model
summary(age_model)
lrtest(age_model)
# Create a new data frame for predictions
predict_data_age <- data.frame(
  age = factor(c("18-35","35-55", "55-70", "70 and above")), levels = c("18-35","35-55", "55-70", "70 and above"))


# Predict probabilities for each socioeconomic status
predicted_probs_age <- as.data.frame(predict(age_model, newdata = predict_data_age, type = "probs"))
predicted_probs_age$age <- predict_data_age$age

# Reshape the data for plotting
plot_data_age <- predicted_probs_age %>%
  pivot_longer(cols = c("Negative", "Neutral", "Positive"), names_to = "Response", values_to = "Probability")

# Create the barplot
age_plot <- ggplot(plot_data_age, aes(x = age, y = Probability, fill = Response)) +
  geom_bar(stat = "identity", position = "dodge") +
  scale_fill_manual(values = c("Negative" = "darkred", "Neutral" = "blue", "Positive" = "forestgreen")) + 
  labs(x = "Age group",
       y = "Probability") +
  theme_classic()+
  theme(
    axis.title = element_text(size = 16),  # Increase axis labels font size
    axis.text = element_text(size = 14)    # Increase tick labels font size
  )




library(ggplot2)
library(gridExtra)

# Combine the plots in a 2x2 grid
combined_plot <- grid.arrange(age_plot, loc_plot, edu_plot, gen_plot, ncol = 2)

# Display the combined plot
combined_plot









